My.RunNetMHCPan <- function(seq, allele, rthParam = 0.50, rltParam= 2.0, tParam = -99.9002){
  seqfile <- tempfile(pattern = "RAPItest",fileext = ".fasta")
  seq.p <- seqinr::s2c(seq)
  pLength <- seqinr::getLength(seq.p)
  seqinr::write.fasta(sequences = seq.p, names =seq, file.out = seqfile)
  if(!file.exists(seqfile)){
    stop("tempfile file could no be created")
  }
  hla <- allele
  softwarePath <- RAPInetMHCpan:::.GetPath()
  if(is.null(softwarePath) | !dir.exists(softwarePath)){
    stop("ERROR: missing netMHCpan path")
  }

  if(stringr::str_detect(basename(seqfile),".fasta")){
    datafile <- seqfile
  }else{
    if(stringr::str_detect(basename(seqfile),".pep")){
      datafile <- paste("-p ",seqfile,sep="")
    }else{
      stop("ERROR file should end in fasta or pep")
    }
  }
  if(missing(pLength)){
    long.pep <- paste(8:14,collapse = ",")
  }else{
    long.pep <- pLength
  }

  command <- file.path(softwarePath,"netMHCpan")
  command <- str_replace_all(command,"//","/")
  arguments <- c(file = datafile,
                 syn = paste("-syn ",file.path(softwarePath,"Linux_x86_64/data/synlist.bin"),sep = ""),
                 tdir = paste("-tdir ", file.path(softwarePath,"tmp/TMPXXXXXX"),sep = ""),
                 rdir = paste("-rdir ", file.path(softwarePath,"Linux_x86_64"),sep = ""),
                 hlapseudo = paste("-hlapseudo ", file.path(softwarePath,"Linux_x86_64/data/MHC_pseudo.dat"),sep = ""),
                 thrfmt = paste("-thrfmt ", file.path(softwarePath,"Linux_x86_64/data/threshold/%s.thr.%s"),sep = ""),
                 version = paste("-version ", file.path(softwarePath,"Linux_x86_64/data/version"),sep = ""),
                 allname = paste("-allname ", file.path(softwarePath,"Linux_x86_64/data/allelenames"),sep = ""),
                 rth = paste("-rth ",rthParam, sep = ""),
                 rlt = paste("-rlt ",rltParam, sep = ""),
                 t = paste("-t ",tParam,sep = ""),
                 v = "-v","-BA",
                 a = paste("-a", NULL),
                 l= paste("-l ",long.pep))
  nm <- names(arguments)
  arguments <- str_replace_all(arguments,"//","/")
  names(arguments) <- nm
  res <- do.call(rbind,lapply(hla,function(al){
    arguments["a"] <- paste("-a",al)
    # print(arguments["a"])
    s1 <- system2(command = command, stdout = TRUE, args = arguments)
    # print(paste("Longitud seq:",length(s1)))
    # binders <- c(which(str_detect(s1,"SB")),which(str_detect(s1,"WB")))
    # class(s1) <- "RAPIMHC"
    # if(length(binders)>0){
    #   return(s1[binders])
    # }else return(NA)

    return(.parserMHCi(s1,seq))
  }))
  file.remove(seqfile)
 return(res)
}


.parserMHCi <- function(txt, seq){
  col.names <-  c("Pos","Allele", "Peptide", "Core", "Offset","Dpos","Dlength","Ipos","Ilength","InterCore","SeqName","RawScore","Affy","PercRank","Type")

  id <- which(stringr::str_detect(txt,seq))
  id <- id[-length(id)]
  txt <- txt[id]
  df <- matrix(NA,ncol= 15, nrow=length(id))
  for(x in 1:length(id)){
    ta <- unlist(stringr::str_split(txt[x]," "))
    ta <- ta[stringr::str_detect(ta,"")]
    if(any(stringr::str_detect(ta,"<="))==TRUE){
      ta <- ta[!stringr::str_detect(ta,"<=")]
    }

    df[x,1:length(ta)] <- ta
  }
  colnames(df) <- col.names
  return(df)
}


