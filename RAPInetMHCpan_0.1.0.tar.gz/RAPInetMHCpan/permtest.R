##NGS
seqs <- apply(do.call(rbind,combinat::permn(seqinr::s2c("GLFGDIYLA")))[c(1:sample(1000,],1,function(x) paste(x,collapse = ""))

seqs <- BiocParallel::bplapply(1:1000, function(x, seq) paste(seqinr::permutation(sequence = seq, modele = "base"), collapse = ""), seq = seqinr::s2c("GLFGDIYLA"),
                               BPPARAM = BiocParallel::MulticoreParam(workers = 4))

seqs[[1]]
seqs <- c("GLFGDIYLA","GSFGDIYLA")
seqs <- c("GLFGDIYLA",seqs)
seqs[1:2]
class(seqs)
write.fasta(seqs,names = paste("seq", 1:length(seqs),sep="-"),file.out= "/home/elmer/pep.fasta")


res <- RunNetMHCPan(seqfile = "/home/elmer/pep.fasta", allele = "HLA-A02:01", pLength = 9)
rank <- as.numeric(as.character(res$PercRank))
rank[1]
summary(rank[-1])

hist(rank,200)
boxplot(rank[-1])
quantile(rank,0.05)
sum((rank[1]>rank[-1]))
rank[1:10]
res
log2(0.8338/0.40099)
permutation(s2c("GLFGDIYLA"),modele='base')
