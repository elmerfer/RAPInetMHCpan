#  .OpenConfigFile
#'
#' internal function to load configuration info.
#'
#'
#' @details It will create a RAPI_Confing.RDS file with software location paths and version
#' for NGS data processing. FastQC, TrimGalore,
#'  PLEASE DO NOT DELET this file
#'
#' @return
#' the configuration list. Each slot holds one software
#'
.OpenConfigFile <- function(){
 if( file.exists(file.path(.libPaths()[1],"RAPI_Config.RDS")) == TRUE ){
   config.list <- readRDS(file.path(.libPaths()[1],"RAPI_Config.RDS"))
 }else{
   config.list <- list()
   config.list$main$path <- file.path(dirname("~/.local/bin"),"bin")
   if(dir.exists(config.list$main$path) == FALSE){
     dir.create(config.list$main$path)
     if(dir.exists(config.list$main$path) == FALSE){
       stop(paste("ERROR: Please verify dir creation permitions at",dirname(config.list$main$path)))
     }
   }

   saveRDS(config.list,file.path(.libPaths()[1],"RAPI_Config.RDS"))
   if( file.exists(file.path(.libPaths()[1],"RAPI_Config.RDS")) == FALSE ){
     stop("ERROR can create ConfigFile")
   }
 }
  return(config.list)
}
#  .SaveConfigFile
#'
#' internal function to save configuration info.
#'
#'
#' @details It will save the RAPI_Confing.RDS file after installation of TrimGalore, FASTQC
#'
.SaveConfigFile <- function(conf){
  if( file.exists(file.path(.libPaths()[1],"RAPI_Config.RDS")) == TRUE ){
    saveRDS(conf,file.path(.libPaths()[1],"RAPI_Config.RDS"))
  }else{
    stop("ERROR CONFIG FILE does NOT exists", )
  }
}
#  InstallTrimGalore
#'
#' painless trim_galore installation.
#' please provide the url from https://github.com/FelixKrueger/TrimGalore
#'
#' @param trimTarBall the url of trimgalore, like "https://github.com/FelixKrueger/TrimGalore/archive/0.6.5.tar.gz"
#' @param where (ptional) directory to where the software will be installed. if missing, it will use ~/.local hidden directory
#' @param cutadaptPath the diretory where cutadapt was installed, if missing it assumes ~/.local/bin/cutadapt
#'
#' @export
#' @author Elmer A. Fernández
#'
#' @details It will install TrimGalore, the RAPI_Config.RDS file will be updated in accordance
#'
#' @return
#' if success, the TrimGalore run without inputs and cutadapt location
#'

InstallTrimGalore <- function(trimTarBall , where, cutadaptPath ){
  config.list <- .OpenConfigFile()
  if(length(config.list) == 0){
    if(missing(cutadaptPath)){
      config.list$cutadapt$path <- file.path(dirname("~/.local/bin/cutadapt"),"cutadapt")

      if( any(stringr::str_detect(list.files(dirname(config.list$cutadapt$path)),"cutadapt")) == FALSE){
        stop("ERROR: cutadapt not found, pls verify instalation")
      }
      config.list$cutadapt$version <- as.numeric(system2(command = config.list$cutadapt$path, args = "--version", wait = TRUE, stdout = TRUE))
      print(config.list)
    }else{
      config.list$cutadapt <- file.path(dirname(cutadaptPath),"cutadapt")
      if(any(stringr::str_detect(list.files(config.list$cutadapt),"cutadapt"))==FALSE){
        stop("ERROR: cutadapt not found, pls verify instalation")
      }
    }
  }
  ##lISTO HASTA ACA CUTADAPT
  if(missing(where)){
    config.list$trimgalore$path <- dirname(config.list$cutadapt$path)
  }else{
    config.list$trimgalore$path <- where
  }
  if(stringr::str_detect(trimTarBall, "https")){##URL, download
    download.file(url = trimTarBall, method = "wget",
                  destfile = file.path(config.list$trimgalore$path,"trim_galore.tar.gz"))

    untar(file.path(config.list$trimgalore$path,"trim_galore.tar.gz"), exdir = config.list$trimgalore$path)
    dlist <- list.dirs(config.list$trimgalore$path, recursive = FALSE)
    id<- which(stringr::str_detect(toupper(dlist),"TRIMGALORE"))
    config.list$trimgalore$path <- dlist[[id]]
    config.list$trimgalore$version <- stringr::str_remove(toupper(basename(dlist[[2]])),"TRIMGALORE")
    print(config.list$trimgalore)
    ##Test trimgalore
    system2(command = file.path(config.list$trimgalore$path,"trim_galore"), args = paste("--path_to_cutadapt", config.list$cutadapt$path) )
  }
  .SaveConfigFile(conf = config.list)
}


#  InstallFastQC
#'
#' painless FastQC installation.
#' please provide the url from https://www.bioinformatics.babraham.ac.uk/projects/download.html#fastqc
#'
#' @param fqurl the url of fastqc
#'
#' @export
#' @author Elmer A. Fernández
#'
#' @details It will install FastQC, the RAPI_Config.RDS file will be updated in accordance
#'
#' @return
#' if success, the configuration list file will be printed and the approrpiate fastqc version will appears
#'
InstallFastQC <- function(fqurl){
  # https://www.bioinformatics.babraham.ac.uk/projects/fastqc/fastqc_v0.11.9.zip
  config.list <- .OpenConfigFile()
  download.file(fqurl, method = "wget",
                destfile = file.path(config.list$main$path,"fasqc.zip"))
  unzip(file.path(config.list$main$path,"fasqc.zip"), exdir = config.list$main$path)
  config.list$fastqc$path <- file.path(config.list$main$path,"FastQC")
  system2(command = "ln", arg = c(config.list$fastqc$path, "/usr/local/bin/fastqc"))
  system2(command = "chmod", args = c("755", file.path(config.list$fastqc$path,"fastqc")))
  config.list$fastqc$version <- system2(command = file.path(config.list$fastqc$path,"fastqc"), args = "--version", stdout = TRUE)
  print(config.list$fastqc$version)
  .SaveConfigFile(conf = config.list)
}

RunTrimGalore <- function(file, paired = TRUE, quality = 20, phred33 = "ON", phred64 = FALSE,
                          fastqc = FALSE, max_length, error_rate = 0.1, gzip=TRUE,
                          length = 20, maxn, trimn, outdir, report_file = TRUE,
                          clip_R1, clip_R2, three_prime_clip_R1, three_prime_clip_R2,
                          retain_unpaired, length_1 = 35, length_2 = 35,
                          trim1, cores =4 ){
#   --path_to_cutadapt
  config.list <- .OpenConfigFile()
  if(is.null(config.list$cutadapt$pat)){
    stop("\nERROR: cutadapt not installed\n")
  }
  if(is.null(confir.list$trimgalore$path)){
    stop("\nERROR: trimgalore not installed\n")
  }

  trim.arguments <- c(paired = ifelse(paired,"--paired", NULL))
  if(quality>0){
    trim.arguments <- c(trim.arguments, quality = paste("--quality",quality))
  }else{
    stop("ERROR, quality > 0")
  }
  phred33 <- paste("--phred33", match.arg(phred33, c("ON","OFF")))
  trim.arguments <- c(trim.arguments, phred33 = phred33)
  if(phred64){
    trim.arguments <- c(trim.arguments, phred64 = "--phred64")
  }
  if(fastqc){
    trim.arguments <- c(trim.arguments, fastqc = "--fastqc")
  }
  if(!missing(max_length)){
    trim.arguments <- c(trim.arguments, max_length = paste("--max_length",max_length))
  }
  trim.arguments <- c(trim.arguments, error_rate = paste("-e",error_rate))
  if(gzip){
    trim.arguments <- c(trim.arguments, gzip = "--gzip")
  }else{
    trim.arguments <- c(trim.arguments, dont_gzip = "--dont_gzip")
  }
  trim.arguments <- c(trim.arguments, length = paste("--length",length))
  if(!missing(maxn)){
    trim.arguments <- c(trim.arguments, maxn = paste("--max_n",maxn))
  }
  if(!missing(trimn)){
    trim.arguments <- c(trim.arguments, trimn = paste("--trim-n",trimn))
  }

  if(missing(outdir)==FALSE){
    dir.create(outdir)
    if( dir.exists(outdir) == FALSE){
      stop(paste("ERROR:", outdir, "could not be created" ))
    }else{
      trim.arguments <- c(trim.arguments, output_dir = paste("--output_dir",outdir))
    }
  }else{
    trim.arguments <- c(trim.arguments, output_dir = paste("--output_dir",dirname(file[1])))
  }

  if(!report_file){
    trim.arguments <- c(trim.arguments, "--no_report_file")
  }
  trimgalore <- file.path(config.list$trimgalore$path,"trim_galore")

  trim.arguments <- c(trim.arguments, paste("--path_to_cutadapt", config.list$cutadapt$path))
  trim.arguments <- c(trim.arguments, cores = paste("--cores", cores))

  if(paired){
    file2 <- file
    file2 <- stringr::str_replace_all(file2,"_1.fastq","_2.fastq")
  }else{
    file2=""
  }
  fex <- file.exists(c(file,file2))
  if(all(fex) == FALSE){
    cat(paste("\n",c(file,file2)[!fex],"\n"))

    stop(paste("\nERROR ----\n",paste(c(file,file2)[!fex],collapse = "\n"), "\nthese files do not exists",sep=""))
  }
  # arguments <- c("--paired",sbj$files, "--cores 2 " ,"--path_to_cutadap ~/.local/bin/cutadapt ", paste("-o ",sbj$subjectDir,sep=""))
  print(c(trimgalore,c(file, file2, trim.arguments)))
  # system2(command = trimgalore, args = c(trim.arguments, file, file2))
  return(list(trimgalore,paste(c(trim.arguments, file, file2),collapse = " ")))

  # system2(command = "/home/elmer/.local/bin/TrimGalore-0.6.5/trim_galore" , args = "--paired /home/elmer/Elmer/FLENI/RNAseq/35252/35252_1.fastq  /home/elmer/Elmer/FLENI/RNAseq/35252/35252_2.fastq --output_dir /home/elmer/Elmer/FLENI/RNAseq/35252 --path_to_cutadapt /home/elmer/.local/bin/cutadapt --cores 4")
}


RunFastQC <- function(file, paired = TRUE, outdir, java, min_length, threads,
                      contaminants, adapters, limits, kmers ){
  config.list <- .OpenConfigFile()

  if(is.null(confir.list$fastqc$path)){
    stop("\nERROR: FASTQC not installed\n")
  }
  PE <- paired
  argument.vector <- NULL
  # argument.vector <- c(outdir = "--outdir ", java = "--java ",
                       # extract = "--extract", min_length = "--min_length",
                       # threads = "--threads", contaminants = "--contaminants",
                       # adapters = "--adapters ", limits = "--limits",
                       # kmers = "--kmers")

  if(missing(outdir)==FALSE){
    dir.create(outdir)
    if( dir.exists(outdir) == FALSE){
      stop(paste("ERROR:", outdir, "could not be created" ))
    }else{
      argument.vector <- c(argument.vector, outdir = paste("--outdir",outdir))
    }
  }else{
    argument.vector <- c(argument.vector, outdir = paste("--outdir",file.path(dirname(file[1])),"FastQC_RAPI"))
  }

  if(!missing(java)){
    argument.vector <- c(argument.vector, java = paste("--java",java))
  }

  if(!missing(min_length)){
    argument.vector <- c(argument.vector, min_length = paste("--min_length",min_length))
  }

  if(!missing(threads)){
    nc <- parallel::detectCores()
    if(threads > length(file)*ifelse(PE,2,1)){
      threads <- length(file)*ifelse(PE,2,1)
    }
    if(threads > nc){
      threads <- nc
    }
    argument.vector <- c(argument.vector, threads = paste("--threads",threads))
  }else{
    argument.vector <- c(argument.vector, threads = paste("--threads",1))
  }
  if(PE){
    file2 <- file
    file2 <- stringr::str_replace_all(file2,"_1.fastq","_2.fastq")
  }else{
    file2=""
  }
  if(!missing(kmers)){
    if(2 <= kmers & kmers <=10){
      argument.vector <- c(argument.vector, kmers = paste("--kmers",kmers))
    }else{

      stop(paste("ERROR: 2 <= kmears <=10, you set:", kmers))
    }
  }else{
    argument.vector <- c(argument.vector, kmers = paste("--kmers",7))
  }
  fex <- file.exists(c(file,file2))
  if(all(fex) == FALSE){
    cat(paste("\n",c(file,file2)[!fex],"\n"))

    stop(paste("\nERROR ----\n",paste(c(file,file2)[!fex],collapse = "\n"), "\nthese files do not exists",sep=""))
  }
  print(file)
  print(file2)
  print(argument.vector)
  system2(command = file.path(config.list$fastqc$path,"fastqc"), args = c(file, file2,argument.vector))
}



